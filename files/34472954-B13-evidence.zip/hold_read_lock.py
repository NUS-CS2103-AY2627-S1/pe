import ctypes,pathlib,time,sys
target=pathlib.Path(sys.argv[1]).resolve()
signal=pathlib.Path(sys.argv[2]).resolve()
ready=pathlib.Path(sys.argv[3]).resolve()
kernel=ctypes.WinDLL('kernel32',use_last_error=True)
kernel.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p]
kernel.CreateFileW.restype=ctypes.c_void_p
handle=kernel.CreateFileW(str(target),0x80000000,0,None,3,0,None)
if handle==ctypes.c_void_p(-1).value:raise ctypes.WinError(ctypes.get_last_error())
ready.write_text('Read/delete lock acquired\n',encoding='utf-8')
print('LOCKED '+str(target),flush=True)
try:
    deadline=time.monotonic()+300
    while not signal.exists() and time.monotonic()<deadline:time.sleep(.2)
finally:
    kernel.CloseHandle(ctypes.c_void_p(handle))
    print('UNLOCKED',flush=True)
