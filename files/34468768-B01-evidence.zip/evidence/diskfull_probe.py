import pathlib,subprocess,json,os,errno,hashlib
out=pathlib.Path('/private/tmp/pe-residex-audit/round2');mount=out/'disk-volume'
assert mount.is_mount() and mount.stat().st_dev!=out.stat().st_dev,'Test volume is not separately mounted'
v=os.statvfs(mount);assert v.f_blocks*v.f_frsize<40*1024*1024,'Unexpected test volume size'
base=['/Users/heqianyi/.sdkman/candidates/java/25.0.3.fx-zulu/bin/java','-Dpe.root='+str(mount),'-cp','/Users/heqianyi/Downloads/CS2103T-PE-2026-11-06/RESIDEX/CS2103T-W11-4-RESIDEX.jar:/private/tmp/pe-residex-audit','PeProbe']
p=subprocess.Popen(base,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=(out/'diskfull-probe-stderr.log').open('w'),text=True,cwd=out);events=[]
def req(**q):
 p.stdin.write(json.dumps(q)+'\n');p.stdin.flush();r=json.loads(p.stdout.readline());events.append({'input':q,'output':r});return r
req(action='new',name='full',seed='empty')
for i in range(10):assert req(cmd=f'add n/Existing Client {i} p/{96660000+i} e/existing{i}@example.com')['ok']
data=mount/'full/data.json';initial=data.read_bytes();filler=mount/'filler.bin'
with filler.open('wb',buffering=0) as f:
 for size in [1024*1024,65536,4096,512]:
  block=b'\0'*size
  while True:
   try:f.write(block)
   except OSError as e:
    if e.errno!=errno.ENOSPC:raise
    break
  if f.tell()>40*1024*1024:raise RuntimeError('Unexpected filler size')
free=os.statvfs(mount).f_bavail*os.statvfs(mount).f_frsize
failure=None
for i in range(30):
 before=data.read_bytes();before_clients=json.loads(before)['persons'];command=f'add n/New Client {i} p/{97770000+i} e/new{i}@example.com';r=req(cmd=command)
 if not r['ok']:
  after=data.read_bytes();failure={'command':command,'error':r.get('message'),'freeBytesBeforeCommands':free,'beforeBytes':len(before),'afterBytes':len(after),'beforeClients':len(before_clients),'inMemoryClientsAfterFailure':len(r['all']),'oldFilePreserved':before==after}
  try:json.loads(after);failure['fileStillValidJson']=True
  except Exception as e:failure['fileStillValidJson']=False;failure['jsonError']=str(e)
  (out/'diskfull-before.json').write_bytes(before);(out/'diskfull-after.bin').write_bytes(after);break
p.stdin.close();p.wait(timeout=10)
(out/'diskfull-result.json').write_text(json.dumps(failure,ensure_ascii=False,indent=2));(out/'diskfull-events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2));print(json.dumps(failure,ensure_ascii=False,indent=2))
